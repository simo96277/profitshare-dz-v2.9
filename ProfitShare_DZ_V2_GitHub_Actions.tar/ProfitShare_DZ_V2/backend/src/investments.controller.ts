import { BadRequestException, Body, Controller, Get, Param, Post } from '@nestjs/common';
import { IsNumber, IsString, Min } from 'class-validator';
import { PrismaService } from './prisma.service';

class CreateInvestmentDto {
  @IsString() investorId!: string;
  @IsString() projectId!: string;
  @IsNumber() @Min(0.01) amount!: number;
}

@Controller('investments')
export class InvestmentsController {
  constructor(private readonly prisma: PrismaService) {}

  @Get()
  list() {
    return this.prisma.investment.findMany({
      orderBy: { createdAt: 'desc' },
      include: { project: { select: { title: true } }, investor: { select: { id: true, fullName: true } } },
    });
  }

  @Get(':id')
  get(@Param('id') id: string) {
    return this.prisma.investment.findUniqueOrThrow({
      where: { id }, include: { project: true, allocations: true, distributions: true },
    });
  }

  @Post()
  async create(@Body() dto: CreateInvestmentDto) {
    const project = await this.prisma.project.findUnique({ where: { id: dto.projectId } });
    if (!project) throw new BadRequestException('المشروع غير موجود');
    if (project.status !== 'OPEN') throw new BadRequestException('المشروع غير مفتوح للاستثمار');
    if (dto.amount < Number(project.minimumInvestment)) throw new BadRequestException('المبلغ أقل من الحد الأدنى');
    if (project.maximumInvestment && dto.amount > Number(project.maximumInvestment)) {
      throw new BadRequestException('المبلغ أكبر من الحد الأقصى');
    }
    return this.prisma.investment.create({
      data: {
        investmentNumber: `INV-${Date.now()}`,
        investorId: dto.investorId, projectId: dto.projectId, amount: dto.amount,
        currency: 'DZD', status: 'PENDING',
      },
    });
  }
}

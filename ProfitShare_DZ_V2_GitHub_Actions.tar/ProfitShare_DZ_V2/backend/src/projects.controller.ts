import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { IsNumber, IsOptional, IsString, Min } from 'class-validator';
import { PrismaService } from './prisma.service';

class CreateProjectDto {
  @IsString() title!: string;
  @IsString() description!: string;
  @IsNumber() @Min(0) targetAmount!: number;
  @IsNumber() @Min(0) minimumInvestment!: number;
  @IsOptional() @IsNumber() @Min(0) maximumInvestment?: number;
}

@Controller('projects')
export class ProjectsController {
  constructor(private readonly prisma: PrismaService) {}

  @Get()
  list() {
    return this.prisma.project.findMany({
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, title: true, description: true, targetAmount: true,
        minimumInvestment: true, maximumInvestment: true, currency: true,
        status: true, riskLevel: true, createdAt: true,
      },
    });
  }

  @Get(':id')
  get(@Param('id') id: string) {
    return this.prisma.project.findUniqueOrThrow({ where: { id }, include: { documents: true } });
  }

  @Post()
  create(@Body() dto: CreateProjectDto) {
    const slug = dto.title.toLowerCase().trim().replace(/[^a-z0-9\u0600-\u06ff]+/g, '-').replace(/^-|-$/g, '');
    return this.prisma.project.create({
      data: {
        title: dto.title, slug: `${slug}-${Date.now()}`, description: dto.description,
        targetAmount: dto.targetAmount, minimumInvestment: dto.minimumInvestment,
        maximumInvestment: dto.maximumInvestment, currency: 'DZD', status: 'DRAFT',
      },
    });
  }
}

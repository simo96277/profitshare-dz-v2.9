import { Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { HealthController } from './health.controller';
import { ProjectsController } from './projects.controller';
import { InvestmentsController } from './investments.controller';
import { WithdrawalsController } from './withdrawals.controller';
import { LedgerService } from './ledger.service';

@Module({
  controllers: [HealthController, ProjectsController, InvestmentsController, WithdrawalsController],
  providers: [PrismaService, LedgerService],
})
export class AppModule {}

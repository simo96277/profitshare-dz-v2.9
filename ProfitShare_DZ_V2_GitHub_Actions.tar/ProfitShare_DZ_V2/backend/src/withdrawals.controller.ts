import { BadRequestException, Body, Controller, Get, Post } from '@nestjs/common';
import { IsNumber, IsString, Min } from 'class-validator';
import { PrismaService } from './prisma.service';

class CreateWithdrawalDto {
  @IsString() userId!: string;
  @IsString() bankAccountId!: string;
  @IsNumber() @Min(0.01) amount!: number;
}

@Controller('withdrawals')
export class WithdrawalsController {
  constructor(private readonly prisma: PrismaService) {}

  @Get()
  list() {
    return this.prisma.withdrawal.findMany({
      orderBy: { requestedAt: 'desc' },
      include: {
        user: { select: { id: true, fullName: true } },
        bankAccount: { select: { id: true, bankName: true, ibanLast4: true } },
      },
    });
  }

  @Post()
  async create(@Body() dto: CreateWithdrawalDto) {
    const account = await this.prisma.bankAccount.findFirst({
      where: { id: dto.bankAccountId, userId: dto.userId, status: 'VERIFIED' },
    });
    if (!account) throw new BadRequestException('الحساب البنكي غير صالح أو غير موثق');
    return this.prisma.withdrawal.create({
      data: {
        withdrawalNumber: `WR-${Date.now()}`, userId: dto.userId,
        bankAccountId: dto.bankAccountId, amount: dto.amount, fee: 0,
        netAmount: dto.amount, currency: 'DZD', status: 'REQUESTED',
      },
    });
  }
}

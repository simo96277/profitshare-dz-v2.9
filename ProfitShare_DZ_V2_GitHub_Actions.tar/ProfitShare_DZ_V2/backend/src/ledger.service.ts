import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from './prisma.service';

type LedgerLine = { ledgerAccountId: string; debit: string; credit: string };

@Injectable()
export class LedgerService {
  constructor(private readonly prisma: PrismaService) {}

  async createJournalEntry(input: {
    entryNumber: string;
    entryType: string;
    referenceType?: string;
    referenceId?: string;
    description?: string;
    lines: LedgerLine[];
  }) {
    // Production: keep all money arithmetic as Decimal, never JS floating point.
    const debit = input.lines.reduce((s, x) => s + Number(x.debit), 0);
    const credit = input.lines.reduce((s, x) => s + Number(x.credit), 0);
    if (Math.abs(debit - credit) > 0.000001) {
      throw new BadRequestException('Ledger entry غير متوازن');
    }
    return this.prisma.$transaction((tx) =>
      tx.journalEntry.create({
        data: {
          entryNumber: input.entryNumber, entryType: input.entryType,
          referenceType: input.referenceType, referenceId: input.referenceId,
          description: input.description, status: 'POSTED',
          lines: { create: input.lines.map((x) => ({
            ledgerAccountId: x.ledgerAccountId, debit: x.debit, credit: x.credit,
          })) },
        },
        include: { lines: true },
      }),
    );
  }
}

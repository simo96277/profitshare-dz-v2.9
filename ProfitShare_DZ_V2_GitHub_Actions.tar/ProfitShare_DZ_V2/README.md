# ProfitShare DZ V2

Foundation full-stack:
- Backend: NestJS + Prisma + PostgreSQL
- Mobile: Flutter
- CI: GitHub Actions
- Financial core: double-entry Ledger schema

This is a staging/technical foundation. It does not connect to real-money payment providers or enable public fundraising. Real-money operation requires the appropriate legal/regulatory structure, KYC/AML controls, accounting controls, and a suitable payment arrangement.

## Backend
```bash
cd backend
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run start:dev
```
API: http://localhost:3000/api
Health: GET /api/health

## Flutter
```bash
cd mobile
flutter pub get
flutter run
```

GitHub Actions:
- backend-ci.yml validates Prisma and builds the backend with PostgreSQL.
- build-apk.yml creates the Android Flutter project and builds a release APK.

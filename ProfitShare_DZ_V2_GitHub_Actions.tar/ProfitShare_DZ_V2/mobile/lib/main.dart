import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const ProfitShareApp());

class ProfitShareApp extends StatelessWidget {
  const ProfitShareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ProfitShare DZ',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.green),
      home: const HomePage(),
    );
  }
}

class Project {
  final String id, title, description, status;
  final double targetAmount, minimumInvestment;
  Project({required this.id, required this.title, required this.description,
    required this.targetAmount, required this.minimumInvestment, required this.status});

  factory Project.fromJson(Map<String, dynamic> j) => Project(
    id: j['id'], title: j['title'], description: j['description'],
    targetAmount: double.parse(j['targetAmount'].toString()),
    minimumInvestment: double.parse(j['minimumInvestment'].toString()),
    status: j['status'],
  );
}

class Api {
  static const baseUrl = 'http://10.0.2.2:3000/api';
  static Future<List<Project>> projects() async {
    final r = await http.get(Uri.parse('$baseUrl/projects'));
    if (r.statusCode != 200) throw Exception('تعذر تحميل المشاريع');
    final data = jsonDecode(r.body) as List;
    return data.map((e) => Project.fromJson(e)).toList();
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<Project>> futureProjects;
  @override void initState() { super.initState(); futureProjects = Api.projects(); }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ProfitShare DZ'), centerTitle: true),
        body: RefreshIndicator(
          onRefresh: () async { setState(() => futureProjects = Api.projects()); await futureProjects; },
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                  Text('مرحباً بك 👋', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('V2 متصلة بالـBackend. المدفوعات الحقيقية غير مفعّلة.'),
                ]),
              )),
              const SizedBox(height: 16),
              const Text('المشاريع', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              FutureBuilder<List<Project>>(
                future: futureProjects,
                builder: (context, snap) {
                  if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                  if (snap.hasError) return Card(child: Padding(padding: const EdgeInsets.all(16), child: Text('خطأ: ${snap.error}')));
                  final projects = snap.data ?? [];
                  if (projects.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('لا توجد مشاريع')));
                  return Column(children: projects.map((p) => Card(
                    child: ListTile(
                      title: Text(p.title),
                      subtitle: Text('${p.description}\nالهدف: ${p.targetAmount.toStringAsFixed(0)} DA\nالحد الأدنى: ${p.minimumInvestment.toStringAsFixed(0)} DA'),
                      isThreeLine: true,
                      trailing: Chip(label: Text(p.status)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectDetailsPage(project: p))),
                    ),
                  )).toList());
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ProjectDetailsPage extends StatefulWidget {
  final Project project;
  const ProjectDetailsPage({super.key, required this.project});
  @override State<ProjectDetailsPage> createState() => _ProjectDetailsPageState();
}

class _ProjectDetailsPageState extends State<ProjectDetailsPage> {
  final amount = TextEditingController();
  bool loading = false;

  Future<void> invest() async {
    final value = double.tryParse(amount.text);
    if (value == null || value < widget.project.minimumInvestment) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل مبلغاً صحيحاً')));
      return;
    }
    setState(() => loading = true);
    try {
      final r = await http.post(
        Uri.parse('${Api.baseUrl}/investments'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'investorId': '00000000-0000-0000-0000-000000000000',
          'projectId': widget.project.id,
          'amount': value,
        }),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(r.statusCode >= 200 && r.statusCode < 300
          ? 'تم إنشاء طلب الاستثمار في staging'
          : 'فشل الطلب: ${r.body}'),
      ));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('تفاصيل المشروع')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(widget.project.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Text(widget.project.description),
        const SizedBox(height: 16),
        Text('الهدف: ${widget.project.targetAmount.toStringAsFixed(0)} DA'),
        Text('الحد الأدنى: ${widget.project.minimumInvestment.toStringAsFixed(0)} DA'),
        const SizedBox(height: 24),
        TextField(controller: amount, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'مبلغ الاستثمار', suffixText: 'DA', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        FilledButton(onPressed: loading ? null : invest,
          child: loading ? const CircularProgressIndicator() : const Text('إنشاء طلب استثمار')),
        const SizedBox(height: 12),
        const Text('هذه النسخة لا تنفذ تحويلات مالية حقيقية.'),
      ]),
    ),
  );
}
